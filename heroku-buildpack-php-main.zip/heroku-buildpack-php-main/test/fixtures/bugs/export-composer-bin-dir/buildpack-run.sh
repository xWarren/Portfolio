#!/usr/bin/env bash
atoum --version
